# Instagram-clone-calısması
# Bootstrep eğitimi Ödev-2
## Patika.dev linkim : https://app.patika.dev/isocan
